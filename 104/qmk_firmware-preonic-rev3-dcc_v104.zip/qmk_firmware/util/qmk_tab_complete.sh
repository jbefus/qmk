# Register qmk with tab completion
eval "$(register-python-argcomplete --no-defaults qmk)"
