#define QMK_VERSION "30aae6-dirty"
#define QMK_BUILDDATE "2021-05-09-17:29:43"
#define CHIBIOS_VERSION "breaking_2021_q1"
#define CHIBIOS_CONTRIB_VERSION "breaking_2021_q1"