#define QMK_VERSION "1426ff-dirty"
#define QMK_BUILDDATE "2021-05-09-16:14:58"
#define CHIBIOS_VERSION "breaking_2021_q1"
#define CHIBIOS_CONTRIB_VERSION "breaking_2021_q1"